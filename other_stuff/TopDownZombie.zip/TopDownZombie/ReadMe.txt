assets are by: Riley Gombart

found at:
https://opengameart.org/content/animated-top-down-survivor-player
https://opengameart.org/content/animated-top-down-zombie

